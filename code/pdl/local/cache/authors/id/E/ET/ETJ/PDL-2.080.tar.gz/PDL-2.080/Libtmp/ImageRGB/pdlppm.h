/* prototypes of functions in ppm_quant.c */
int ppm_quant(unsigned char *rin, unsigned char *gin, unsigned char *bin,
	      int cols, int rows, unsigned char *pic8, unsigned char *ilut,
	      unsigned char *olut, int ilen, int newcolors,
	      int mode);
