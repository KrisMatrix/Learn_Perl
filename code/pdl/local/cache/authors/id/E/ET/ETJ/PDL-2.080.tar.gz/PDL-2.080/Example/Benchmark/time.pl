use PDL;
use PDL::Bench;

do_benchmark();
