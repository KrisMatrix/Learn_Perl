char *rdecomp(unsigned char *c, int clen, void *array, int bsize, int nx, int nblock);
char *rcomp(void *a_v, int bsize, int nx, unsigned char *c, int clen, int nblock, int *ret);
